from discord.ext import commands
from discord import app_commands

class RoleManager(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="role_manager", description="Run role_manager plugin command")
    async def role_manager(self, interaction):
        await interaction.response.send_message("role_manager plugin is installed.", ephemeral=True)

async def setup(bot: commands.Bot):
    await bot.add_cog(RoleManager(bot))

import discord
from discord.ext import commands
from discord import app_commands


class Trivia(commands.Cog):
    """Interactive trivia game for Discord servers."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="trivia", description="Start an interactive trivia game")
    @app_commands.describe(difficulty="Difficulty level: easy, medium, or hard")
    async def trivia(self, interaction: discord.Interaction, difficulty: str = "medium"):
        difficulties = {
            "easy": "🟢 Easy",
            "medium": "🟡 Medium",
            "hard": "🔴 Hard",
        }

        if difficulty.lower() not in difficulties:
            await interaction.response.send_message(
                "❌ Invalid difficulty. Choose: easy, medium, or hard",
                ephemeral=True,
            )
            return

        embed = discord.Embed(
            title="🎯 Trivia Game",
            description=(
                f"**Difficulty:** {difficulties[difficulty.lower()]}\n\n"
                "Question: What is the capital of France?"
            ),
            color=discord.Color.blue(),
        )
        embed.add_field(name="A)", value="London", inline=False)
        embed.add_field(name="B)", value="Paris", inline=False)
        embed.add_field(name="C)", value="Berlin", inline=False)
        embed.add_field(name="D)", value="Madrid", inline=False)

        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="trivia_score", description="Check your trivia score")
    async def trivia_score(self, interaction: discord.Interaction):
        embed = discord.Embed(
            title="📊 Your Trivia Score",
            description="**Correct Answers:** 0\n**Total Questions:** 0\n**Win Rate:** 0%",
            color=discord.Color.green(),
        )
        await interaction.response.send_message(embed=embed, ephemeral=True)


async def setup(bot: commands.Bot):
    await bot.add_cog(Trivia(bot))


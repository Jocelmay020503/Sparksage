from discord.ext import commands
from discord import app_commands

class UserStats(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="user_stats", description="Run user_stats plugin command")
    async def user_stats(self, interaction):
        await interaction.response.send_message("user_stats plugin is installed.", ephemeral=True)

async def setup(bot: commands.Bot):
    await bot.add_cog(UserStats(bot))

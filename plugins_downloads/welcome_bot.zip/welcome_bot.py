from discord.ext import commands
from discord import app_commands

class WelcomeBot(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="welcome_bot", description="Run welcome_bot plugin command")
    async def welcome_bot(self, interaction):
        await interaction.response.send_message("welcome_bot plugin is installed.", ephemeral=True)

async def setup(bot: commands.Bot):
    await bot.add_cog(WelcomeBot(bot))

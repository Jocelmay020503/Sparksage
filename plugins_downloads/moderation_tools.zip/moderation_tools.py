from discord.ext import commands
from discord import app_commands

class ModerationTools(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="moderation_tools", description="Run moderation_tools plugin command")
    async def moderation_tools(self, interaction):
        await interaction.response.send_message("moderation_tools plugin is installed.", ephemeral=True)

async def setup(bot: commands.Bot):
    await bot.add_cog(ModerationTools(bot))

import discord
from discord.ext import commands
from discord import app_commands


class SuggestionSystem(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.suggestions = {}

    @app_commands.command(name="suggest", description="Submit a suggestion")
    @app_commands.describe(suggestion="Your suggestion for the server")
    async def suggest(self, interaction: discord.Interaction, suggestion: str):
        suggestion_id = len(self.suggestions) + 1
        self.suggestions[suggestion_id] = {
            "user": interaction.user.display_name,
            "content": suggestion,
            "votes": 0,
        }

        embed = discord.Embed(
            title="💡 Suggestion Submitted",
            description=f"**Suggestion #{suggestion_id}**\n{suggestion}",
            color=discord.Color.blue(),
        )
        embed.set_footer(text=f"Submitted by {interaction.user.display_name}")
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="suggestions", description="View submitted suggestions")
    async def suggestions(self, interaction: discord.Interaction):
        if not self.suggestions:
            await interaction.response.send_message(
                "No suggestions yet. Use /suggest to add one.",
                ephemeral=True,
            )
            return

        embed = discord.Embed(
            title="💡 Server Suggestions",
            description=f"Total suggestions: {len(self.suggestions)}",
            color=discord.Color.blue(),
        )
        for suggestion_id, data in self.suggestions.items():
            embed.add_field(
                name=f"#{suggestion_id} - {data['user']}",
                value=f"{data['content']}\n👍 {data['votes']} votes",
                inline=False,
            )

        await interaction.response.send_message(embed=embed, ephemeral=True)


async def setup(bot: commands.Bot):
    await bot.add_cog(SuggestionSystem(bot))

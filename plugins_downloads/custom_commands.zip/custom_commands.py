from discord.ext import commands
from discord import app_commands

class CustomCommands(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.command(name="custom_commands", description="Run custom_commands plugin command")
    async def custom_commands(self, interaction):
        await interaction.response.send_message("custom_commands plugin is installed.", ephemeral=True)

async def setup(bot: commands.Bot):
    await bot.add_cog(CustomCommands(bot))

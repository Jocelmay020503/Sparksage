import discord
from discord.ext import commands
from discord import app_commands


class MusicPlayer(commands.Cog):
    """Text-based music queue system."""

    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self.queue = {}
        self.now_playing = {}

    def get_guild_queue(self, guild_id: int):
        if guild_id not in self.queue:
            self.queue[guild_id] = []
            self.now_playing[guild_id] = None
        return self.queue[guild_id]

    @app_commands.command(name="play", description="Add a song to queue")
    @app_commands.describe(song="Song title")
    async def play(self, interaction: discord.Interaction, song: str):
        if not interaction.guild:
            await interaction.response.send_message("Server only command.", ephemeral=True)
            return

        guild_id = interaction.guild.id
        queue = self.get_guild_queue(guild_id)
        queue.append(song)

        if len(queue) == 1:
            self.now_playing[guild_id] = song
            await interaction.response.send_message(f"🎵 Now playing: **{song}**")
        else:
            await interaction.response.send_message(
                f"📝 Added to queue: **{song}** (#{len(queue)})"
            )

    @app_commands.command(name="queue", description="Show queue")
    async def queue_cmd(self, interaction: discord.Interaction):
        if not interaction.guild:
            await interaction.response.send_message("Server only command.", ephemeral=True)
            return

        guild_id = interaction.guild.id
        queue = self.get_guild_queue(guild_id)
        if not queue:
            await interaction.response.send_message("Queue is empty.")
            return

        lines = [f"**{index}.** {song}" for index, song in enumerate(queue, start=1)]
        await interaction.response.send_message("\n".join(lines))

    @app_commands.command(name="skip", description="Skip current song")
    async def skip(self, interaction: discord.Interaction):
        if not interaction.guild:
            await interaction.response.send_message("Server only command.", ephemeral=True)
            return

        guild_id = interaction.guild.id
        queue = self.get_guild_queue(guild_id)
        if not queue:
            await interaction.response.send_message("Nothing to skip.")
            return

        skipped = queue.pop(0)
        self.now_playing[guild_id] = queue[0] if queue else None
        if queue:
            await interaction.response.send_message(
                f"⏭️ Skipped **{skipped}**. Now playing **{queue[0]}**"
            )
        else:
            await interaction.response.send_message(f"⏭️ Skipped **{skipped}**. Queue is empty.")

    @app_commands.command(name="stop", description="Clear queue")
    async def stop(self, interaction: discord.Interaction):
        if not interaction.guild:
            await interaction.response.send_message("Server only command.", ephemeral=True)
            return

        guild_id = interaction.guild.id
        count = len(self.queue.get(guild_id, []))
        self.queue[guild_id] = []
        self.now_playing[guild_id] = None
        await interaction.response.send_message(f"⏹️ Cleared queue ({count} song/s).")


async def setup(bot: commands.Bot):
    await bot.add_cog(MusicPlayer(bot))


